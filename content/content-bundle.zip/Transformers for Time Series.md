
Requirements:

- Multivariate
- External variables should be includable (multivariate)
- Should be able to handle nan
- Good repo
- Adaptable without insane effort

Justus: 

I should really formulate out why exactly it is not possible.

[https://docs.google.com/spreadsheets/d/1We41BIKEj0FbuKGpv94qWzBcTtpQS0jsE19tP3eeCRU/edit#gid=0](https://docs.google.com/spreadsheets/d/1We41BIKEj0FbuKGpv94qWzBcTtpQS0jsE19tP3eeCRU/edit#gid=0)

There are many different versions. 
**Notable distinct features:** Special Attention to account for running speed, potential usage of frequency domain, pretraining for Time series representation maybe usage of recurrency. 
**Problem:** Hard to compare. Datasets are malliciously not unified....

[[@zhou_fedformer_2022]]
[[@liu_pyraformer_2021]]
[[@klimek_long-term_2021]]
[[@wu_autoformer_2021]]
[[@zerveas_transformer-based_2020]]
[[@lim_temporal_2020]]
[[@wu_deep_2020]]
[[@noauthor_papers_nodate]]
[[@li_enhancing_2020]]
[[@zhou_informer_2021]]

## Summary papers:
[[@wen_transformers_2022]]
[[@zeng_are_2022]]

## For Time series non-stationarity
[[@liu_non-stationary_2022-1]]

## For anomaly detection
[[@tuli_tranad_2022]]


| Model | FedFormer | PyraFormer | Klimek | Autoformer | TRANSFORMER-BASED FRAMEWORK | Temporal fusion Transformer | The Influenza Prevalence Case | FiLM: | Breaking the bottleneck | Informer |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Usable? | Possibly  | Possibly + | Not really | Possibly | Possibly | Possibly + | Probably not.  | No.  | Probably not. | Probably. + |
| Advantages: | Seems to have a nice foundation | Multi resolution attention he hi | Some form of special attention | Decomposition, Auto-correlation mechanism instead of vanilla attention | Uses transformer to extract feature vectors from multivariate time series | Interpretable multi horizon, external variables, RNN + attention | Vanilla. seems like a bad repo | Uses some special GRU alternatives. Not published yet. No Transformer base | Conv self attention layers, LogSparse attention | All in one prediction, log sparese + some other ideas |
| Git?  |  |  |  |  |  |  |  | - |  |  |
| Comment: | complicated | Fast, explicitly handles covariates | Not really well commented, low citation | Interesting | Unsupervised pertaining! | Google paper, clear description | Nothing new. Just apply vanilla and pray | This unit might be interesting | repo okay but has no description | Baseline, Big Repo |
| Stars | 181 | 109 |  | 733 | 319 | 65? Probably more |  |  | 290 | 2900 |
| citations  | 23 | 14 |  | 93 | 135 | 302 |  |  | 455 | 434 |
| Year | 2022 | 2021 |  | 2021 | 2020 | 2019 |  |  | 2019 | 2020 |
| Weather | 0.403 |  |  | 0.419 |  |  |  |  |  | 0.831 |
| Traffic MSE | 0.596 |  |  | 0.660 |  |  |  |  |  |  |
| ELEC |  | 0.719 |  |  |  |  |  |  |  |  |

