
This should be at least a paper. 

The setup would look like this: 

Compare different filling strategies on different gap situations and datasets. Show that the filling of tfts is much more true to the real data (especially with external variables)

Show this by filling synthetic data and MSE AND detect anomalous events and show that data filled with TFT can be detected less easy

**Progress:**  
Currently Justus works on the TFT filling on one dataset and the Jena experiment data. 

**Evaluation:** 
My current idea is to use [[Anomaly detection in TS]] and especially distribution based methods such as [[[[@barz_detecting_2018]]]] to double check if we can find a difference in distribution between imputed data and original data 


Steps to do for publication:  ✔

1. Decision for datasets for comparison
2. Creation for synthetic data
3. Baseline Methods (repeat fill, mean, seasonal mean)
4. Baseline TS modelling (Arima,  Sarimax) 
5. Other Deep Learning Method (DeepAR)
6. SSM approach
7.  Direct comparion on forecasting and gap filling. 
8. Selection of anomaly detection method
9. Apply anomaly detection to filled data and see if there is a difference.
10. Propose this as a way to evaluate fills without groundtruth