I assume these will be mostly indirect effects. 
Something like increased [[Biomass]] might be an direct effect.
