#GOAL Make educated guesses and/or construct some timeseries for data which I have no time series right now but which will be important.

At the beginning i though I can use the interpolation to perform Causal Inference on TS but I think this is not a good idea (We basically never know if something is really true). Therefore I keep this open to create some clever way to estimate not measured variables. This is more of an sideproject but might also fit in the thesis as a sidenode.

#INPUT Base data, phenological cycles, sattelite data, point measurement, management data, maybe some proxy that is available?

#CURRENT

-  I have some first Sattelite data but thats all. Also I need to probably make it by hand

#NEXT

-  Aquire all INput data
-  Try for especially LAI. This should be possible. 
-  If this works try the remaining relevant variables.