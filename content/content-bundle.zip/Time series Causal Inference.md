Based on  [[@vowels_dx2019ya_2022]]:


There are two big groups: 

Granger causality methods. and dynamic Causaltity. 

I am not entirely sure if [[@krich_estimating_2020]] is in these categories. Need to revisit. I assume it is also possible to directly use methods from [[Sample based Causal Inference]] on unrolled graphs. 



According to [[@assaad_survey_2022]] There are again some categories of approaches: 


## Granger causality


## Constrained based

## Noise-based approaches

## Score based approaches



