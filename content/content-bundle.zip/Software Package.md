
#GOAL At the end, the ecological departement should recieve a Causal Inference package. This should probably also include my pyGlet Display and some additional functionalities

#INPUT What ever methods I found to be especially useful for Causal Inference in the ecological domain. 

#CURRENT

-  I have some very first demos which can be recycled later to build a nice webapp  with Plotly and Dash. I should however seperate the methods from the webapp in order to make them usable without the app

-  [[! (Important)]] The display works and has some first feature requests. I should add this in the next year.