---
title: Biodiversity effects on ecosystem functioning in a 15-year grassland experiment: Patterns, mechanisms, and open questions
authors: Wolfgang W Weisser, Christiane Roscher, Sebastian T Meyer, Anne Ebeling, Guangjuan Luo, Eric Allan, Holger Beßler, Romain L Barnard, Nina Buchmann, François Buscot, others
year: 2017
---

 is the big summary paper of conducted research at the jena experiment. Can be referenced to find different experiments and additional literature. 
   