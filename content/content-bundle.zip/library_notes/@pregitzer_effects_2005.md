---
title: Effects of Soil Temperature on Nutrient Uptake
authors: K.S. Pregitzer, J.S. King
year: 2005
---

