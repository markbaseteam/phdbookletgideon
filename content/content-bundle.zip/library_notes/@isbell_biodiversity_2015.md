---
title: Biodiversity increases the resistance of ecosystem productivity to climate extremes
authors: Forest Isbell, Dylan Craven, John Connolly, Michel Loreau, Bernhard Schmid, Carl Beierkuhnlein, T. Martijn Bezemer, Catherine Bonin, Helge Bruelheide, Enrica de Luca, Anne Ebeling, John N. Griffin, Qinfeng Guo, Yann Hautier, Andy Hector, Anke Jentsch, Jürgen Kreyling, Vojtěch Lanta, Pete Manning, Sebastian T. Meyer, Akira S. Mori, Shahid Naeem, Pascal A. Niklaus, H. Wayne Polley, Peter B. Reich, Christiane Roscher, Eric W. Seabloom, Melinda D. Smith, Madhav P. Thakur, David Tilman, Benjamin F. Tracy, Wim H. van der Putten, Jasper van Ruijven, Alexandra Weigelt, Wolfgang W. Weisser, Brian Wilsey, Nico Eisenhauer
year: 2015
---

