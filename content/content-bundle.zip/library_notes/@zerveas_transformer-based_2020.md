---
title: A Transformer-based Framework for Multivariate Time Series Representation Learning
authors: George Zerveas, Srideepika Jayaraman, Dhaval Patel, Anuradha Bhamidipaty, Carsten Eickhoff
year: 2020
---

