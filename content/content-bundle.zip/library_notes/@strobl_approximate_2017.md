---
title: Approximate kernel-based conditional independence tests for fast non-parametric causal discovery
authors: Eric V. Strobl, Kun Zhang, Shyam Visweswaran
year: 2017
---

