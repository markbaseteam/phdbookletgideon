---
title: Autoformer: Decomposition Transformers with Auto-Correlation for Long-Term Series Forecasting
authors: haixu wu, Jiehui Xu, Jianmin Wang, Mingsheng Long
year: 2021
---

