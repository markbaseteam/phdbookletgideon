---
title: Deep Transformer Models for Time Series Forecasting: The Influenza Prevalence Case
authors: Neo Wu, Bradley Green, Xue Ben, Shawn O'Banion
year: 2020
---

