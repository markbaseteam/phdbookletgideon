---
title: Planned missing data designs and methods: Options for strengthening inference, increasing research efficiency and improving animal welfare in ecological and evolutionary research
authors: Daniel W. A. Noble, Shinichi Nakagawa
year: 2021
---

