---
title: Papers with Code - FiLM: Frequency improved Legendre Memory Model for Long-term Time Series Forecasting
authors: 
year: 
---

