---
title: A review on outlier/anomaly detection in time series data
authors: Ane Blázquez-García, Angel Conde, Usue Mori, Jose A Lozano
year: 2020
---

is a review of different types of anomalie and outlier detection. Key insights: There are  model base, density based and histogram based methods for both single and multidimensional time series. 
    It seems like the best idea is to use models since they can be used for different task aswell. 