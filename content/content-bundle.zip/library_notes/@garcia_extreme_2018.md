---
title: Extreme anomaly event detection in biosphere using linear regression and a spatiotemporal MRF model
authors: Yanira Guanche Garcia, Maha Shadaydeh, Miguel Mahecha, Joachim Denzler
year: 2018
---

is a method developed to detect anomalous events in multivariat time series. It is based on Simple ARMA models and the Mahalanobis distance. Good candidate for a baseline method