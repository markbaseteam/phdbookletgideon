---
title: Causal inference in statistics: An overview
authors: Judea Pearl
year: 2009
---

