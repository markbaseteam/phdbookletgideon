---
title: A New Framework for the Time- and Frequency-Domain Assessment of High-Order Interactions in Networks of Random Processes
authors: Luca Faes, Gorana Mijatovic, Yuri Antonacci, Riccardo Pernice, Chiara Barà, Laura Sparacino, Marco Sammartino, Alberto Porta, Daniele Marinazzo, Sebastiano Stramaglia
year: 2022
---

