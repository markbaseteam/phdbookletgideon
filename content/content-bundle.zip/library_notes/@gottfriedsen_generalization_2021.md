---
title: On the Generalization of Agricultural Drought Classification from Climate Data
authors: Julia Gottfriedsen, Max Berrendorf, Pierre Gentine, Markus Reichstein, Katja Weigel, Birgit Hassler, Veronika Eyring
year: 2021
---

