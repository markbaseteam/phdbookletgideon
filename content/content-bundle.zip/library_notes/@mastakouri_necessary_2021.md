---
title: Necessary and sufficient conditions for causal feature selection in time series with latent common causes
authors: Atalanti A Mastakouri, Bernhard Schölkopf, Dominik Janzing
year: 2021
---

s a theoretical work on some special case where causal inference with common causes works well. Not relevant I belief since almost impossible to understand (2pages proves) 