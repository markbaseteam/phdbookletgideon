---
title: Patterns and drivers of biodiversity–stability relationships under climate extremes
authors: Hans J. De Boeck, Juliette M. G. Bloor, Juergen Kreyling, Johannes C. G. Ransijn, Ivan Nijs, Anke Jentsch, Michaela Zeiter
year: 2018
---

