---
title: FEDformer: Frequency Enhanced Decomposed Transformer for Long-term Series Forecasting
authors: Tian Zhou, Ziqing Ma, Qingsong Wen, Xue Wang, Liang Sun, Rong Jin
year: 2022
---

