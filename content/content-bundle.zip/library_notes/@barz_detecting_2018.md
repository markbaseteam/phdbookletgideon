---
title: Detecting regions of maximal divergence for spatio-temporal anomaly detection
authors: Björn Barz, Erik Rodner, Yanira Guanche Garcia, Joachim Denzler
year: 2018
---


is a method from Björn to detect divergent intervals in multidimensional timeseries. It is based on different divergence measures between intervals and the rest of the data. Should prove useful for my case