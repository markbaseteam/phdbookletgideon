---
title: Biodiversity and stability in grasslands
authors: David Tilman, John A Downing
year: 1994
---

