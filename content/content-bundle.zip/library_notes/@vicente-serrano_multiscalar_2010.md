---
title: A Multiscalar Drought Index Sensitive to Global Warming: The Standardized Precipitation Evapotranspiration Index
authors: Sergio M. Vicente-Serrano, Santiago Beguería, Juan I. López-Moreno
year: 2010
---

