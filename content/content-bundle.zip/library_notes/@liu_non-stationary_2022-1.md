---
title: Non-stationary Transformers: Rethinking the Stationarity in Time Series Forecasting
authors: Yong Liu, Haixu Wu, Jianmin Wang, Mingsheng Long
year: 2022
---

