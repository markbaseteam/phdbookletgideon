---
title: Estimating causal networks in biosphere–atmosphere interaction with the PCMCI approach
authors: Christopher Krich, Jakob Runge, Diego G. Miralles, Mirco Migliavacca, Oscar Perez-Priego, Tarek El-Madany, Arnaud Carrara, Miguel D. Mahecha
year: 2020
---

