---
title: Are Transformers Effective for Time Series Forecasting?
authors: Ailing Zeng, Muxi Chen, Lei Zhang, Qiang Xu
year: 2022
---

