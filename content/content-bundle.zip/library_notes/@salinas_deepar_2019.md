---
title: DeepAR: Probabilistic forecasting with autoregressive recurrent networks
authors: David Salinas, Valentin Flunkert, Jan Gasthaus
year: 2019
---

