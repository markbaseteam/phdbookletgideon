---
title: Diversity-dependent production can decrease the stability of ecosystem functioning
authors: Andrea B. Pfisterer, Bernhard Schmid
year: 2002
---

