---
title: Diverse forests are cool: Promoting diverse forests to mitigate carbon emissions and climate change
authors: Rémy Beugnon, Emma Ladouceur, Marie Sünnemann, Simone Cesarz, Nico Eisenhauer
year: 
---

