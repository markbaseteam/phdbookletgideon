---
title: Tree species identity determines wood decomposition via microclimatic effects
authors: Felix Gottschall, Sophie Davids, Till E. Newiger‐Dous, Harald Auge, Simone Cesarz, Nico Eisenhauer
year: 2019
---

"We studied the influence of tree species richness, tree species identity, and microclimatic conditions on wood decomposition in a 12‐year‐old tree diversity experiment in Germany, We assessed wood mass loss, soil microbial properties, and soil surface temperature in high temporal resolution. Our study shows a significant influence of tree species identity on all three variables"
Results:
tree species richness effects are not significant for wood decomposition. Rather tree identity seems to be the driving force. Single trees had significant effects on different measures.
Different species isolate the ground which leads to temperature differences, which in turn has a influence on e.g microbial biomass. which in turn influences decomposition

Explanations:
- richness effects might be only relevant in nutrient-poor contexts.
- Young sight and richness effects might only show over time
- All trees were planted at the same time. Might disguise interaction effects
- group interactions could be responsible