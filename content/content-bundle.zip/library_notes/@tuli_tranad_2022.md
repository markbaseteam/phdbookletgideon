---
title: TranAD: Deep Transformer Networks for Anomaly Detection in Multivariate Time Series Data
authors: Shreshth Tuli, Giuliano Casale, Nicholas R. Jennings
year: 2022
---

