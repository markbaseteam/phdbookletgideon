---
title: Long-term series forecasting with Query Selector – efficient model of sparse attention
authors: Jacek Klimek, Jakub Klimek, Witold Kraskiewicz, Mateusz Topolewski
year: 2021
---

