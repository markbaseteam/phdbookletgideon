---
title: Informer: Beyond efficient transformer for long sequence time-series forecasting
authors: Haoyi Zhou, Shanghang Zhang, Jieqi Peng, Shuai Zhang, Jianxin Li, Hui Xiong, Wancai Zhang
year: 2021
---

