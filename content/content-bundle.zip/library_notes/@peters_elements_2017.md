---
title: Elements of causal inference: foundations and learning algorithms
authors: Jonas Peters, Dominik Janzing, Bernhard Schölkopf
year: 2017
---

Groundwork for causal inference. I should add a complete summary of this book when I a finished. It includes theory and connections to ML