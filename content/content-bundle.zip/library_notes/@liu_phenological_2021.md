---
title: Phenological mismatches between above- and belowground plant responses to climate warming
authors: Huiying Liu, Hao Wang, Nan Li, Junjiong Shao, Xuhui Zhou, Kees Jan van Groenigen, Madhav P. Thakur
year: 2021
---

