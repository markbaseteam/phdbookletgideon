---
title: Deep factors with gaussian processes for forecasting
authors: Danielle C Maddix, Yuyang Wang, Alex Smola
year: 2018
---

 is a method that combines Deep State models with gaussian processes to model the long term and short term patterns of ts. Short paper with not a lot of support inside.. Method still might be interesting. 