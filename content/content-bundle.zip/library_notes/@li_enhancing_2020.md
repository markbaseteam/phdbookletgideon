---
title: Enhancing the Locality and Breaking the Memory Bottleneck of Transformer on Time Series Forecasting
authors: Shiyang Li, Xiaoyong Jin, Yao Xuan, Xiyou Zhou, Wenhu Chen, Yu-Xiang Wang, Xifeng Yan
year: 2020
---

