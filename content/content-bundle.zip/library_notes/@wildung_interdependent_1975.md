---
title: The interdependent effects of soil temperature and water content on soil respiration rate and plant root decomposition in arid grassland soils
authors: R. E. Wildung, T. R. Garland, R. L. Buschbom
year: 1975
---

