

#GOAL The goal is to understand how Soil layers are related with each other and how this relationship changes with diversity. 

#INPUT As a starting point, soil temperature dataset from the Jena experiment, especially from block2. Maybe we can also add the soil mosisture somehow in this analysis. Should explain dynamical changes.

#CURRENT


-  I started two areas here that relate to each other but which can be seperated.  [[Autocorrelation]] and [[Causal Inference Heat Flow]]

-  This is currently on ice since I want to understand the [[Physical relationships]] in the system better before I continue. Especially for the Causal Inference, this should give me a lot of restrictings and perspectives on how to think about this system.
