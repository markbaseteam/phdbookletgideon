
#GOAL Show that there is an actual statistical effect from plant diversity on the soil temperature
For the thesis, this is the basic evaluation before we can start any further Causal analysis

#INPUT As a starting point, we have the raw output data from [[Data preprocessing]] (Station, Temp, soil, covariates)

#CURRENT


Two distinct papers are planned here.
[[Plant diversity Buffers soil temperature]]
[[Extreme Weather relationship to diversity effects]]
