
Diversity changes the interactions between variables. 

Generally, I am only concerned with [[Plant Diversity]] since it is the controlling variable. 
Other diversity perspectives, microbial, instects etc. are also possible. Typically they are also effect directly by Plant diversity.