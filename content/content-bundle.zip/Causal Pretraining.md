#GOAL In very simple terms: Deep Neural Network + Syntetic data generation = Learned Causal inference

#CURRENT


-  I started the first simple generator class. 
-  A designed a nice script but it is not yet perfect

#NEXT 

-  [[! (Important)]] fix the experiment script so experiments will be consistent for as long as possible. 
-  [[! (Important)]] Now I need to make the whole think more general. I will probably try to get as much input from the group since this is a hard task. 
-  While the generator is growing I will try to add more and more comlexity to the graph class and observe whether the model can handle it. 
-  Architecture is still a big question. This is to be investigated
-  What are Differential euqation models again? How can I use them? 
-  Generator can be recycled for many other papers. (e.g. Test Conditional Independence testing failure cases)




Concerning the data generation process [[Synthetic TS with Pytorch]]