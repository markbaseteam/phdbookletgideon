

Time series methods can be divided into many different goals. Tee main ones are

[[Time series modeling]]

[[Anomaly detection in TS]]

[[Causal Inference in TS]]

of course they are all connected.