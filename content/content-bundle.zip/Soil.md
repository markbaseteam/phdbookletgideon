
#Todo I should collect here a lot of information about general soil properties. 


Soil Temperature effects
[[@pregitzer_effects_2005]] How does soil temperature effects nutrient uptake
[[@wildung_interdependent_1975]] Soil respiration and root decomposition as effected by Soil temp
