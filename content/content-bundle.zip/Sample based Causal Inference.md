
(Causal discovery)
With no temporal information available,  a set of methods is available to retrieve the causal Graph from data. Importantly, lagged relationships are not possible so variables in the system always only exist as a single node. 

[[@vowels_dx2019ya_2022]] a lot of the summed up knowledge here comes from here. Very nice summary paper.

WHERE ARE SEMs?


(# Causal Discovery Methods Based on Graphical Models)
[[@glymour_review_2019]]
I think this is giving a new viewpoint on different causal approaches. I should start from here and get the Information on the methods out.

A couple of important things that I should not here for all algorithms: 
 - Assumptions
 - Specific idea
 - Relationship to others

There are 4 classes of models
Further they can be classified as 
**Optimization based vs search/combinatoric based** 
Traditionally we have clever heuristics to simple search the space of all possible graphs. Recently, many optimize a function that helps finding the correct graph somehow (This is basically everything deep learning related.)


and
**local (edges alone) or global scoring**

## Constraint-Based

Basically concerned with conditional independence testing.  To remove edges. After this additional conditions like removal of v-structures may be applied to further reduce the number of undirected edges. The PC algorithm is the most prominent method in this class

## Score-Based Causal Discovery

Here we simply try to score a given candidate Graph in combination with the observational data. I assume these might be sometimes differentiable but often search heuristics are used to end up with a final graph decision.

## Structural Asymetry-based

Two classes are described here. Given some strong assumptions, we can actually read out the direction of an edge by observing correlation patterns in residuals. Only works if at least one of the noise terms is non-gaussian. 
A different approach is based on the fact that $f(x)$ and $f(y|x)$  should be independent in reality. If we model both directions and find dependence in one direction we might conclude the other direction. A lot of assumptions typically go into these methods. 

## Intervention-based

Only possible if we have more than just observational data.  We can  direct edges by observing the effects of an intervention. On variables. Possibly this can also work if we do not specifically have an idea on what exactly is intervened on. 





## FCI (Fast conditional independence)


## GES (Greedy equivalence search)





