

With no temporal information available,  a set of methods is available to retrieve the causal Graph from data. Importantly, lagged relationships are not possible so variables in the system always only exist as a single node. 

So far

