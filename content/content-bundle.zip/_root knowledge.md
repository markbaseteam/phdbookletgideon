

This is the root node of my PHD project. 

#Todo I should add the proposal skeleton, the main goals and the general outline for my work here. 
#Todo I have to fill in all the information that I have from my first paper into this knowledge graph

#Todo  Find a way to import zotero references in here.



Mainly, the knowledge graph should include 3 big areas: 

-  [[Ecology]] and geological knowledge
-  [[Time series]] methods
-  [[Causal Inference]] literature and methods

Furthermore, some specifications for the [[Jena Experiment]] should be included here aswell

Finally, we have a number of [[math concepts ]]that I should keep track of here aswell



I want to keep this graph knowledge based. So I will add progress updates in Notion insteasl

This is however not restricted. It should probably overflow into general ML and AI research topics


