- How does heat flow in the soil system?
- How does moisture change the ground
- Soil consistency... etc. etc. 

This should help me make a more consistent model with reality. 