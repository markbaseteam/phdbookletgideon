


I should collect whatever method that is using some kind of deep learning approach. This way, I should be able to find out what is still not done. Links directly to what I have to do in [[Causal Pretraining]]



[[@assaad_survey_2022]],  [[@vowels_dx2019ya_2022]]. Have a lot of sources but are not extensive. I collected more.


Deep Learning can be used in the following ways as far as I can imagine. 
-  Nonlinear function for granger causality
-  Direct weight interpretation as causal (probably based on sparsity)
-  




[[Time series Causal Inference]] **TIME SERIES**






[[Sample based Causal Inference]] **Non-temporal**