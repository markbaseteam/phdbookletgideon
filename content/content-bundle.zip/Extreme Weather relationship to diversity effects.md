Very new. Needs some adjustments. 

  Yuanyuan and Nico want to start another analysis to explain the magnitude of the diversity effect in relation to climate drivers. This is closely connected to the main paper and should be an easy access paper I can help here with the modelling, especially because we will get new data from the ecotrons with this. Nico plans a new experiment with extreme weather analysis
My proposition here would be the following, to a) Predict the relationship b) propose methodology how to attack such a question. 

Concerning the explanation of the Diversity effect, I have the following proposition:
Typically, If we model such effects, we use linear models to guarantee explainability and have an understandable hypothesis. However, there is no guarantee that the underlying relationships behave this way (Almost certainly not). To attack this regime and to improve the understanding of the whole thing, I want to propose the following:

1.  Fit a standard linear model for the diversity effect.
2.  Contrary, what is the maximum predictive power we can reach (Explainability wholly ignored, AI stuff :) )
3.  Is there a significant difference in the predictive power of some linear model that can be easily understood and, let's say, a Deep Neural Network
4.  If yes. Find a middle way. This should help improve our understanding of the drivers of diversity effects.

I find this necessary because I believe that nonlinear, cyclic, and multivariable interaction effects play a role in these systems, and we shouldn't abstract them away too much.


The exact things still have to develop. This is not in the focus right now.  Importantly, this is very related to the Causal Inference approach, simply because large impact on the magnitude might suggest also a causal relation. 

This might also help me with actually using the high resolution temp data. I can model down to the 10-min diversity effect with this. 

This might also be used for predicting the soil temperature by itself. Which in turn can provide a way to estimate the soil temperature without measuring it (In different depths?)