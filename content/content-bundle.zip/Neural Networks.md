
Neural networks come in various different variants and with many different extensions. 
Here I want to collect many of them. 




**Bayesian Deep Networks**
https://jorisbaan.nl/2021/03/02/introduction-to-bayesian-deep-learning.html


**Variational Autoencoders**
https://www.jeremyjordan.me/variational-autoencoders/
