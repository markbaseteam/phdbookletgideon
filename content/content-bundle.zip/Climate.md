
I am mostly interested in [[Climate --> Soil]] and [[Climate --> Plants]]
On the global level, as implications [[Soil --> Climate]] might also become interesting.



Extreme climate effects:
[[@gottfriedsen_generalization_2021]] Drought classification from climate data
[[@liu_phenological_2021]] Climate change effects above and belowground differently
[[@vicente-serrano_multiscalar_2010]] SPEI paper (drought index)