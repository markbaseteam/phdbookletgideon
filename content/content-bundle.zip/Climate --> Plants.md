
#Todo How does the climate effect plants in general.