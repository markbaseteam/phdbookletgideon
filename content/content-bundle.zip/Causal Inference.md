

Causal Inference has a million different approaches and borrows from many disciplines. 

Some important notes:

**There is [[Time series Causal Inference]] and [[Sample based Causal Inference]].**
Both are needed. Intuitively, I feel like having time series information can help with this whole process

**Methods are often inconsistent. Ground truth is often not optainable except for synthetic data which makes proving causal relationships very hard.**

I am saving a lot of background theory here: [[CI definitions]]

A lot of approaches can be classified as either **search based or optimization based**. Optimization has a long tradition but I believe optimization based approaches are more promising. 

## Books 

[[@peters_elements_2017]]
motivates the usage of causal inference in ML and argues that it is extremely important to solve many open problems. I should write a complete summary when finished.


[[@pearl_causal_2009]]
Pearl Buch


Some methods:

[[@shadaydeh_causality_nodate]] (GC)
[[@garcia_attribution_nodate]]

[[@mastakouri_necessary_2021]]
[[@maddix_deep_2018]]


Specifically:

I want to collect approaches with Deep Learning here:
[[Deep Learning for Causal Discovery]]