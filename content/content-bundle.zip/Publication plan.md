

Current plans and venues for the publication of my work: 

- General Problem: Either the workshops are not out yet for the next conference or the Deadline is already over (Exception ICML 2023)
- I am struggelling a little on aiming at Pure ML conferences with the work that I am currently doing. Most of it is rooted a little too much in Ecology 


### 2023 

##### Plant Diversity Increases Soil Temperature Stability
First. The Joint Soil Temp Paper should be submitted to **Nature**. Alternative would be another Journal such as **Global  Frontiers or Agriculture, Ecosystems and Environment**

#### Causal Inference for Ecological Processes
Secondly I want to conclude my research on sample based Causal Inference for Jena experiment data until the start of June. Since this is mostly an application paper for Causal Inference Methods in comparison to SEM modelling, the story that I want to tell suggests that this might also be a **Journal paper**. Same venues as above might apply. Otherwise there might be a workshop on the big conferences about **AI in Climate Science or Ecology** where I can submit alternatively. 

#### Roots paper
I am offering here some more extended analysis according to above. Should end up in another journal (I have little influence where exactly)

#### Extend the work of Violeta on Drought detection and attribution
The content might suggest a publicatin in **Conference on Artificial Intelligence for Environmental Science
**

#### Study on Time series modelling based strategies for Imputation
I would like to start a cooperation project on this where multiple people can add specific methods for data imputation. I will provide baselines, datasets and modular code to make everything consistent.  The venue for this should be something in the direction.


#### Bidirection Transformers for Time Series Imputation
Extending a TFT architecture to work bidirectional would be nice. If this works I should aim for main Track of some A level conference (AAAI, ICML, NEURIPS etc.)

#### Causal Pretraining
If it works. this should be a main track paper for either ICML, NEURIPS or AAAI (Especially Neurips specifically mentions CI in their list of topics)


Other things: 

Soil Temperature dataset paper. Only possible when the main paper is published so nothing done on this right now

Whatever Tristan is submitting. His responsibility

Resubmission of CINC content. Only possible with dataset public. 


