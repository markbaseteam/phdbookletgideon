

This area of research is quite old and comes originally from Economics. During my research, I found that there are a couple of different "schools" of approaches that I want to list here: 



Classical Methods (Sarimax)

$$
y_{t} = \sum_{i=1}^{p} \phi y_{t-i} +
\sum_{k=1}^{r} \beta_{k} x_{tk} +
\sum_{j=1}^{q} \theta_{j} \epsilon_{t-j}  +
\sum_{n=1}^{P} \alpha_{n} y_{t-sk} +
\sum_{n=1}^{Q} \gamma _{n} \epsilon_{t-sn} +
\epsilon _{t}
$$
Models the linear relationship between yt and various other terms.
For seasonal data we can either add Seasonal fourier terms in $r$ or simple deseason the data before we model. Of course we can also include trends. Order is typically selected via either Information Criteria IF we have the same amount of external parameters or we use Test data to score. This should always be the baseline comparion to any more comlex method! Statsmodels has a nice implementation. Also exists in Vectorized form.



State Space Models

I so far did not read too much on this but the idea is to have a hidden state that we assume is not observable and which represents the true dynamics of the system. We can add exogenous variables here of course.  An RNN is an SSM!

$$
\dot{x}_z = A_z x_z +B_z u_z
$$
$$
\dot{y}_z = C_z x_z +D_z u_z
$$

Deep Learning:

Here we have many many different Architecutres for Time series modeling.  Most importantly I think the usage of attention or recurrency groups them best. 

[[@salinas_deepar_2019]]  --> Deep Autoregressive,  Amazon Forecasting system (probably not anymore)

[[@lim_temporal_2020]] --> Deep learning Transformer + RNN. Seems to be a very night middlepath between full Transformer and RNN based methods

[[@zhou_informer_2021]] --> Best Paper award AAAI. Full transformer architecture with a special Attention scheme

There are many more Transformer archtiectures...[[Transformers for Time Series]]



## Possible useful concepts

[[Fourier Terms]]



Insights SSM vs Transformers

On the Transfomer vs LSTM debatte.  I believe wether or not to represent a process of a time series with a hidden state or via direct mapping really depends on the timeseries that you want to model. Some processes are also in reality directly limited by their direct parent making a SSM model quite attractive. Others however might have long range dependencies and it could be that in these cases Transformers make sense. (FIR vs IIR models).  Need to rethink about this again a little but i think this in general makes very clear: The model has to fit whatever you want to model!
Maybe I should look at the theoretical proofs why recurrency is a nice feature in time series representation and which benefits it exactly gives. Transformers in the frequency domain might be an entire different story. Here attention should always make sense since the units are not directly informed.  ?????????????ßß Nedd more thinking