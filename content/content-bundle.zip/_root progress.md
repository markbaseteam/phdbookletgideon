

I want to organize my current PhD progress here. 
Open Projects, what is done, what failed etc.

So far I believe I can seperate my work packages are the following:

[[Data preprocessing]] ✓
[[Statistical Background]] ✓
[[Causal Inference in the Jena experiment]]
[[Estimate TS]]
[[Method developement]]
[[Software Package]]

[[Publication plan]]

Formal
This project focuses on soil-plant-climate systems, and specifically the impact of plant  
diversity on such systems. The hypothesis that is to be tested in this context is whether  
plant diversity can buffer the effects of climate extremes and promote long-term microbial  
functioning by stabilizing micro-climate. To test this hypothesis, a strong focus will  
lie on discovering cause-effect relationships in the named system. An unprecedently  
detailed long-term dataset on climate, plant community properties, soil microclimatic  
conditions, soil microbial biomass, and respiration, which was collected over many years  
at the Jena experiment site, will be utilized to investigate and discover these causal  
relationships exhaustively. This research is highly interdisciplinary, leveraging different  
Machine Learning methods such as time-series analysis, causal inference methods, and  
anomaly detection to find precise answers to posed questions.  
These relationships can occur over multiple timescales, which motivates a multiple  
timescale analysis of this system and its cause-effect relationships.  
Of course, this Hypothesis derives from different knowledge and open questions in the  
literature. [[@weisser_biodiversity_2017]] suggests that A) Plant diversity drives many ecosystem processes and  
B) mechanisms of ecosystem processes are still under investigation. Furthermore, [[@gottschall_tree_2019]] suggests that Effects of plant diversity are mediated by changes in the micro-climate.

Informal: 
since I am new in this Research group, I wanted to introduce myself and my project to  
you :) My name is Gideon and I recently started my Ph.D. (an iDiv Flexpool project)  
at the FSU in Jena. In my project, I will investigate the impact of plant diversity on  
plan-soil-climate interactions. The focus here will be on the discovery of cause-effect  
relationships in these plant-soil-climate systems. The Jena experiment provides with me  
the necessary data and is therefore a central component of my project. To achieve my  
goal, I will primarily use Machine Learning Techniques and specifically Causal inference  
methods. This will be a little different in comparison to other more classical statistical  
approaches. As you might already guess, this project is very interdisciplinary. In fact,  
I am a computer scientist that tries to take a deep dive into biodiversity research. So I  
am very excited to talk with all of you at some point :)

[[Thesis summaries]]


Original Timeplan
![[timeplan.png]]

Some things have changed here. 
1.  Added statistical background paper. I think this makes the thesis more round since it lays out the ground for the causal analysis
2. The first anomaly detection method was more or less a fail. (Weather anomalies are not necessarily mathematical anomalies if we look at it with a rather simple approach).  For the first project we just take extreme events instead of anomalies which worked fine for this approach. Depending what I want to do later I need to come back to this topic (also for KI4KI)
3. Modelling is currently done via SEM, for gap filling and during causal Inference
4. Cuasal inference is divided in multiple parts ([[Causal Inference in the Jena experiment]])
5. Software developement is already in progess if I have something that is round enough (Causal inference demos, Jena experiment display etc. etc.)


## Result demonstrations

The main goal will be to show causal connections that 
a) make sense based on the knowledge already existing. 
b) is consistent with different findings. 
Since there is no real groundtruth, benchmarking should be used to show the effectiveness of any method on different datasets before applying it to the Jena experiment dataset


Novelty:
- Show statistical connection between plant diversity and soil temperature --> Novel
- Introduce new gap filling methods to the bioDiv literature --> Novel
- Apply causal inference to biodiversity research --> Novel
- Advance some causal inference method
- Library development
- Anomaly detection method evaluations  --> novel application