


Some comments: 

- Also playing a role for compression, I want to sum up the concepts that are interesting in terms of statistical analysis
- For most of the logterms, the base is not entirely fixed. Typically log2 (Shannon)
- The wikipedia entries about these topics are very well written.



### Entropy

$$
E = -\sum_{i=1}^{N} P_{i} log_{2} P_{i}
$$
Where p is the probability of occurrence of the i-th possible value of the source symbol. 
log_2 is not a necessity. It is the default (Shannon Entropy), Intuitively, the entropy _HX_ of a discrete random variable _X_ is a measure of the amount of _uncertainty_ associated with the value of _X_ when only its distribution is known. (Wiki). This can be easily extended to joint probability distributions (**joint entropy,**) by ($p(x,y)$) or conditional distributions $p(x|y)$ (**conditional entropy**). I dont quite get how that works for continous variables


### KL-Divergence (also relative entropy)

Measures the difference between two probability distributions. This is not a metric since it is not symetrical! It is the expectation of the logarithmic difference between the probabilities P and Q where the expectation is taken using the probabilities P .


$$
KL(P || Q) = \sum_{xeX} P(x) * log(\frac{Q(x}{P(x)})
$$
 For contious cases we exchange the sum with $\int_{-\infty}^{\infty}$



### Mutual information
_[Mutual information](https://en.wikipedia.org/wiki/Mutual_information)_ measures the amount of information that can be obtained about one random variable by observing another.Let $( X , Y )$ be a pair of random variables with values over the space $X × Y$. If their joint distribution is $P_{( X , Y )}$ and the marginal distributions are $P_{x}and P_{y}$ , the mutual information is defined as:

$$
I(X,Y) = D_{KL}(P_{(X,Y)}|| P_{(X)} \otimes P_{(Y)})
$$
If the two variables are independent, then $D_{KL}$ is 0 meaning the information is 0. The higher, the more information can be gained from one variable for the other. 


### Conditional Mutual Information

$$
I(X;Y |Z) = \mathbb{E}_{z} [ D_{KL}(P_{(X,Y)}|| P_{(X)} \otimes P_{(Y)}) ]
$$


###  Interaction information

![[inter_inf.png]]
The idea is to measure the mutual information between more than 2 variables
For three variables, the interaction information measures the influence of a variable Z ![Z](https://wikimedia.org/api/rest_v1/media/math/render/svg/1cc6b75e09a8aa3f04d8584b11db534f88fb56bd) on the amount of information shared between X and Y. It is defined as: 

$$
I(X_{1};...;X_{n+1}) = I(X_{1};...;X_{n}) - I(X_{1};...;X_{n} | X_{n+1})$$

Can be positive or negative.

### Synergy and Redundancy

As stated by [[@faes_new_2022]]: 
Synergy: statistical Interactions that can be found in a network but not in its parts
Redundancy: group interactions that can be explained through their sub group interactions


### Partial information decomposition

Alternative to Interaction information. I should revisit this if it pops up. 


### O-information 





### Kolmogorov complexity

$nt_{-\infty}^{\infty}$

/home/stein/project_repos/linear_model_gap_bench/results/arima_gap_middle_effects.csv