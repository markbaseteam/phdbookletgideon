Obsidian help structuring knowledge by allowing for the construction of a flexible knowledge graph in markdown.


I am saving my knowledge aswell as my current progress and plans in here. 

### Options to look at the booklet:

1. You can just read the markdown files. (Links not included)
2. Download https://obsidian.md/, clown repository and open it in obsidian
3. I've created an easy access online view here https://phdbookletgideon.markbase.xyz/



