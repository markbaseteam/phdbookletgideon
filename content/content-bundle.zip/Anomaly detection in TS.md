
Keep in mind: Depends always a little on what kind of anomaly we want to detect!

Some possible methods: 


## Based on distribution similarity
[[@barz_detecting_2018]]

## Based on model residuals
[[@garcia_extreme_2018]]


## Review Papers. Give a really nice Categorization!

[[@blazquez-garcia_review_2020]]
model base, density based and histogram based methods for both single and multidimensional time series. 

[[@wang_progress_2019]]



I did not put too much effort into this area since it did not seem to be too relevant so far. 