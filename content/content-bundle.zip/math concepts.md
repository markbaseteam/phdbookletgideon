
Every abstract mathematical concept that is nontrivial and relevant to my work should end up here. 



[[Mahalanobis distance]]
 https://www.machinelearningplus.com/statistics/mahalanobis-distance/





[[Neural Networks]]

[[Fourier Terms]]

[[CI definitions]]

[[Information theory]]