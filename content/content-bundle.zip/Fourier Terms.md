

Used to account for seasonality in linear model. 

$$
 f_{i,s,t} = sin(2\pi i \times  \frac{t}{m}))
$$
$$
 f_{i,c,t} = sin(2\pi i \times  \frac{t}{m}))
$$

$i$ defines how many order we want. (We can add as many as neded to describe the seasonal cycle)
We basically construct a term that has a seasonal cycle according to our knowledge.  We can add as many as we want.