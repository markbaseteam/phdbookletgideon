The things I want to do as soon as possible.
I should cycle through the graph periodically to update what I already finished.



starting at     
 - [[_root progress]] or
 - [[_root knowledge]]
 helps with orientation. 

Currently the links are broken online... Trying to find out why