#GOAL The most important part in my PhD concerning my future ML career. I want to develop a) some new causal inference appraoches that are based on Deep Learning: [[Causal Pretraining]]. Furthermore, seperating Seasonality and Trends to intervene on individual parts should be very beneficial for the Ecology domain: [[SSM Causal Inference]]. I want to work on this jointly with Wasim and Maha

Me and Wasim also had a lot of interesting ideas that might be worth some investigations. So far I think I should focus on the named two only to not loose track.



#CURRENT


-  I started with the [[Causal Pretraining]]
-  Me and Saba will start with [[SSM Causal Inference]] in January.
