
The goal is to use and develop causal inference methods to understand the soil-plant-climate interactions. In general we have the big problem that the resolution of the measured variables differ so drastically that we cannot analyze the whole system jointly and based on one resolution. Alternatively, I aim at looking at the whole system from different causal perspectives to at the end form a consistent joint picture([[Causal System Synthesis]]).  The following subprojects can seperated here for the causal inference


[[Yearly system analysis]]
[[Weather effects on Diversity effect and soil temperature]]
[[Understanding Soil layer relationships]]


Furthermore, I need to spend some more time on [[Causal Inference Theory]]