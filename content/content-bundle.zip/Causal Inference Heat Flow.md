
#GOAL I want to apply TS based Causal Inference methods here to see how layers of air and soil temperature interact with each other. 

#INPUT High resolution time series of soil and air temperature + maybe moisture. 

#CURRENT

-  So far I used Granger Causality, Granger Causality in the Frequency domain and PCMCI. The results are not really consistent. I need to first understand more about the system and the methods. This idea might also be ill formed. Causality should go in all directions i guess (But not jumping layers). The big problem is here that everything is cyclic which makes Causal Inference very hard. Either The Frequency domain approach or [[SSM Causal Inference]] might help here
