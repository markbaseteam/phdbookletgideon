


Basic idea is this: 

$$
Y_t = \sum_{i=1}^{maxlag} (f(Y_{t-i})) + e + C 
$$
Where Y is a vector with n variables, e is a noise vector and C is a Trend vector. 


Implementationwise, examples should be generated on the fly on the GPU. To do this, I want to define each component of the model as a Tensor or function. By Tensor operations we then can generate the data.  


I want to have the following things flexible (ordered by complexity increase):

- linear parameter or functional relationship
- stationarity, non-divergent
- Sparsity of the relationships
- n of variables
- Trend
- individual noise types (possible 0)

Introduce a step later: 
- n of lags
- variable masking (hidden confounding)
- Interaction effects
- Gaps in data filled with something  (basically removing causality for specific timesteps.)


**Open problems:** 

-  I need to garantuee a reasonable sampling from this distribution
-  Generation process should be fast
- Interaction effects might be potentially very huge: 
$$
Y_t = \sum_{i=1}^{maxlag} (f(Y_{t-i})) +   (f(Y_{t-i ; t-maxlag},Y_{t-i ; t-maxlag})) +  e + C 
$$
