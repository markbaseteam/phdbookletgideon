
Theoretical fundation for [[Gap filling]]

In general there are many different ways to fill a time series and I need to collect standard approaches here. 


## Statistical approaches
-  KNN
-  Interpolation
-  Repeat fill
-  Seasonal mean


## Data distribution modelling

We can in theory use any kind or relational model (doesnt even have to be a TS model) to fill data. 
In theory, we would expect, that the better the model the better the imputation. But this depends a little on the data and the quality of the model fit!


## How to evaluate? 

If we dont have ground truth to test the imputations against (Which we never have considering we apply these methods to real data), then we need to do something different ([[Gap filling]])



## Alternatives

[[@noble_planned_2021]]  How to plan experiment with expected missing data