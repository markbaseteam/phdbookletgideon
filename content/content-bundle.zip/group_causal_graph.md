


How does the interactiopn between the different groups look like? This is my current idea what to consider and what not. Since I am interested in the local effects, I especially leave out everything that feedsback into climate from soil (this is only relevant on the global scale which I am not concerned with)

These effects are not considered!
```mermaid  
graph TD;  
PLANT--> CLIMATE;
SOILCLIMATE --> CLIMATE;
NUTRIENTS --> CLIMATE;
BIOTICSOIL --> CLIMATE;
```


What remains is the following system. 

```mermaid  
graph TD;  
PLANTS--> BIOTICSOIL;
PLANTS --> X;
CLIMATE --> X
NUTRIENTS -->X
X --> SOILCLIMATE;
CLIMATE --> PLANTS;
NUTRIENTS--> PLANTS
NUTRIENTS--> BIOTICSOIL
SOILCLIMATE--> BIOTICSOIL
SOILCLIMATE--> PLANTS
BIOTICSOIL--> PLANTS
BIOTICSOIL--> NUTRIENTS
```


I believe the following **DIRECT** links are existing but are  too small to be considered.


```mermaid  
graph TD;  
NUTRIENTS--> SOILCLIMATE;
BIOTICSOIL--> SOILCLIMATE;
SOILCLIMATE-->NUTRIENTS;
PLANTS-->SOILCLIMATE;
PLANTS-->NUTRIENTS
```


Currently I am testing only for the interaction effect. I need to read the proposal again to see what else I can try to test.


Many of this is built on my intuition so careful :)








