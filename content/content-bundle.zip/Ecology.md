This is a root node for my necessary ecology knowledge concerning my PHD


In general I need to be aware of [[Soil]] - [[Climate]] -  [[Plants]] interactions. 
The effects of [[Diversity]] should alter the relationships and is our controlling variable

The interaction of these can be understood according to the literature.  
Or based on data driven inference.
Many interactions that are reported in the literature are however not tested on Causal relation but rather on correlational based. So probably complete set of variables can be interconnection in a much sparser graph (maybe?)

I extended the 3 groups into [[group_causal_graph]] to be more precise. I should find some knowledge on this.

[[! (Important)]] After our nature paper is finalized I should completely summarize the literature and build a complete knowledge graph of it. I need it for my thesis (I will forget it until then :)) 