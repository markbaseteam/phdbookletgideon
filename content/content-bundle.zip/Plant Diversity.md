
I should add here a very long list of insights from the literature. 

Basically I am mostly interested in the effect [[Plant Diversity  --> Soil]]
Other interactions might be interesting on the global level [[Plant Diversity  --> Climate]], which should be mentioned in general but which I can not test for directly


Some literature on the the effects of plant diversity and biodiversity more generall: 

[[@weisser_biodiversity_2017]] is the big summary paper of conducted research at the jena experiment. Can be referenced to find different experiments and additional literature. 

Other core paper:  [[@isbell_biodiversity_2015]] 
This is an metanalysis of many studies that tested for a diversity effect on ecosystem productivity. Based on data from 46 experiments (grassland) from arround the world and linear mixed effect models, it was concluded that biodiversity has a significant effect on resistance against climate extremes (both wet or dry and extreme duration) . No consistent biodiversity effect on the resilience of ecosystems was found (depends on dry /wet duration). Resistance --> drop in biomass Resilience --> recover after event
"Biodiversity there stabilizes ecosystem productivity and probably productivity-dependent ecosystem services during climate events that are moderate or extreme"

[[@gottschall_tree_2019]]

We assessed wood mass loss, soil microbial properties, and soil surface temperature in high temporal resolution. Our study shows a significant influence of tree species identity on all three variables"


There are a million of papers on different effects.

[[@beugnon_diverse_nodate]]     Diverse Forests and their effectd
[[@de_boeck_patterns_2018]]     BioDiv Stability relationship under extreme weather
[[@tilman_biodiversity_1994]]      BioDiv  Stability in grassland
[[@wilson_biodiversity_0000]]     General Biodiversity effects
[[@pfisterer_diversity-dependent_2002]] Diversity dependent producting can decrease ecosystem production


