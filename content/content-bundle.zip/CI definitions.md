





## Graph definitions


**DAG** 

directed edges, no cycles. We can transform this DAG to a real Causal model/explanation by adding functions and noise to all transitions. 


**Adjacent**
Two nodes are connected directly

**Immorality / V-structures**
Two npn-adjacent nodes have a common child. (Collider is C)
```mermaid  
graph TD;  
A--> C;
B--> C;



```

**Markov Assumption**

Every node is independent of everything else given its parents. 

$$
P(X) =  \prod_{i}^{d} P(X_{i}|pa_{i})
$$

**D-Seperation:** 

A set X is indepedent of set Y given a third set Z
Conditions: 
$$
X_i \rightarrow X_j \rightarrow X_k ,
X_i \leftarrow X_j \leftarrow X_k ,
X_i \leftarrow X_j \rightarrow X_k,
$$
And: 
$$
X_i \rightarrow X_j \leftarrow X_k
$$
Shouldnt be true for any element $X_j$ and its decendants in Z 

If there is a set Z, it implies markovian conditional independence in the joint distribution. 
**d-seperated / d-connected** depending whtehr the condition holds

D-faithfulness is given when every Conditional independence in the distribution corresponds to a d-seperation in the graph: 
$$
A \perp \!\!\! \perp_{Px} B  | C    \Rightarrow  A \perp \!\!\! \perp_{d-sep}B|C
$$

Counterexample: 
```mermaid  
graph TD;  
A-->|w1| B;
A-->|w2| C;
B-->|w3| C;

```
If W2 - W1*W3 = 0 --> Corr(A,C) = 0 BUT not :  $A \perp \!\!\! \perp_{sep_d} C|B$
Generally if paths cancel each other out this is a problem. 

According to Wikipedia [Bayes-Ball-Algorithmus](https://de.wikipedia.org/w/index.php?title=Bayes-Ball-Algorithmus&action=edit&redlink=1 "Bayes-Ball-Algorithmus (Seite nicht vorhanden)") is good to find d-seperation



**Markov Equivalence class**

Graphs are typically not uniquely identifiable since they encode the same conditional dependencies. Two graphs belong in this category if they have the same skeleton and the same immoralities (V-structures).

**Completed Partially DAG**
Used to represent MECs.  Edges might be undirected if multiple graphs in the MEC  exist that have different directions of an edge. 

**Sufficiency**
No hidden cofounders, no data holes. This is a super strong assumption.  DAG results are not valid if this does not hold!

**Minimality**
P is not compatible with any subgraph of G (This basically states that the graph should have no unnecessary links)

**Acyclic Directed Mixed Graphs**

We can represent hidden confounding in these graphs. Leave out for now. I am not sure if this is even used in practice. There is also a very big set of different graph definitions to account for specific problems. Should revisit them at a later point if needed. 


**Temporal Priority**
Cause before effect :)

