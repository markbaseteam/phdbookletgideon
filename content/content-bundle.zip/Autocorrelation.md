I used Lagged Cross correlation to understand the temperature relationships in the ground. 
This is consistent so far but I need to spend some more time on making the story of it consistent. Probably this will be an ecological paper.

#NEXT 
- Repo is all over the place. If I want to submit this, I really need to clean and make it consistent. 