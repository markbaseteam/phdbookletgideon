

# 3Minute thesis
Informational content that I used:

As we all know, one of the effects of global warning is an increase in extreme weather events such as drought, heatwaves and flood. Due to that, the question arises how to mitigate such events, especially on our environment. One possible mitigator is bio, specifically plant diversity. Plant diversity is already well established to stabilize ecosystems over time. However, whether it can also buffer against the effects of climate extremes is not yet clear. Furthermore, the mechanisms that guide this possible effect are also still in the dark. My PhD thesis aim at answering both questions by not only investigation whether plant-diversity can help but also how exactly it does that.

I am planning to use a subset of modern machine learning methods called Causal Inference methods to understand the causal structures of plant-soil-climate systems Causal structures display the causes why different variables change the way they are and are therefore essential to answer both the Whether and especially the How question. Simply, they tell us more than mere Correlations patterns. After all Correlations is not Causation. 

I build on a long-term dataset with multiple billion datapoints from the Jena experiment a experimental field side here in Jena. Unraveling the causal connections from this data which is unfortunately non-trivial. Fortunately, I am actually a computer scientist which specializes in Machine Learning techniques but which is also interested in ecological questions, so I am hopefully well equipped for this task.

So far, I investigated the correlation patterns between soil variables, climate and plant diversity and a positive effect of plant diversity is visible. High plant diversity is correlated with a more stable soil-climate which is in turn beneficial for all forms of life in general. Additionally, this effects seems to actually get stronger during extreme weather events. While this gives a strong baseline for my analysis, as a next step, I need to exactly understand the causal mechanisms that take place since again: correlation is not causation. If everything goes well, I hope I will be able to provide a strong case for the importance of plant diversity and an explanation how it actually helps the environment. Thank you for your attention. 

Climate change LEADS TO MORE EXTREME WEATHER EVENTS 
MITIGATE ESPECIALLY ON ECOSYSTEMS
PLANT DIV HELPS 
MY THESIS AIMS AT BOTH THE QUESTION WEHTER and HOW 
TO TACKLE THESE QUESTIONS
CAUSAL INFERENCE METHODS TO UNDERSTAND CAUSAL STRUCTURES OF PLANT SOIL CLIMATE SYSTEM. 
THESE DESCRIBE WHICH VARIABLES ARE THE REASON FOR CHANGE OF OTHER VARIABLES 
AS AN EXAMPLE WE ALL KNOW SUN CAUSES AIR TEMPERATURE INCREASE BUT WE DONT KNOW WHAT ARE CAUSES OF PLANT DIVERSITY
ESSENTIAL FOR HOW
SIMPLY THEY TELL US MORE THAN CORRELATIONS. 
USING A DATASET FROM THE JENA EXPERIMENT A FIELD SITE 
HARD TO UNRAVEL 
I AM COPUTERSCIENTIST WITH INTEREST IN ECOLOGICAL QUESTIONS
SO FAR: I iNVESTIGATED CORRELATION PATTERN. EFFECT IS THERE
ALSO DURING EXTREME EVENTS
OF COURSE NOW I NEED TO CONTINUE THE CAUSAL ANALYSIS TO UNDERSTAND 
IF EVERYTHING GOES WELL I HOPE I CAN DELIVER A STRONG CASE AND ALSO EXPLAIN THE MECHANISMS
THANK YOU FOR YOUR ATTENTION


# Idiv conference
In a world that has to increasingly deal with extreme weather events,
the question of how to mitigate the effects of such events, especially on ecosystems, becomes essential. Our research focuses on plant diversity and the impact it can have, specifically on soil-plant-climate systems. The hypothesis that we test in this context is whether plant diversity can buffer the effects of climate extremes by stabilizing the soil temperature in different depths. We analyze an unprecedented long-term climate and soil temperature dataset which was collected over almost 20 years at the "Jena Experiment" site. Our first initial results suggest a significant effect of plant diversity on the mean and the variance of the seasonal soil temperature. Furthermore, this effect seems to get stronger during extreme weather events such as extreme heat. 


