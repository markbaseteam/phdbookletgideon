
#Todo I want to synthesize the information from the different channels here. 


[[Climate --> Plants]], [[Climate --> Soil]],
[[Plant Diversity  --> Soil]], [[Plant Diversity  --> Climate]],
[[Soil --> Climate]], [[Soil --> Plant Diversity]]