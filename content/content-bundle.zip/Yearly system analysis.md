
#GOAL The goal is to understand how soil temperature is affected by other variables. 

#INPUT As a starting point, we have the data from the Jena experiment and the current results of the SEM modelling from [[Statistical Background]]

#CURRENT

-  From the SEM analysis, we have the hyothesis that the diversity effect on the soil temperature stability is mainly caused through the indirect channels SOC and LAI. Unfortunately there is no real TS data for these variables avaliable which currently restricts me to use sample-based Causal Inference methods which is unlucky. Also the SOC samples are only available for  6 years. 

-  Currently there is no individual Soil moisture in the relationship. I need to include this, especially since it is also a time series.
-  Since I can use multiple methods, I need to somehow synthesize consistentcy. To do this. I want to test multiple methods, representations, and variables to find the most consistent things.
-  I think adding  TS-based Causal Inference should be the goal.  But this needs the data first


#NEXT

-  [[! (Important)]] I think I want to spend a little more time here on the [[Causal Inference]] to really understand the differences between methods properly. This will help synthesizing the results. 
-  After this I need to add individual soil moisture.
-  Run multiple methods as currently done in the Oberseminar and synthesize. 
-  After this we can go for the temporal relationship.

Steps: 
-  Clean current repo and build clean data agnostic input
-  Revisit the[[group_causal_graph]] and include additional variables especially soil moisture
-  Revisit the representation of the variables
-  Theoretical revision of [[Sample based Causal Inference]] methods. Focus especially on their theoretical assumptions and see which methods I can use
-  Implement a collection of all methods and their description
-  Execute all Experiments with all Variable types
- Conclude and select the proper variable collection
-  Until then the nature paper should be submitted and I can reuse our results from the for comparison
- Write Paper

#CURRENT 
- So far I used multiple methods from the Causal Inference Toolbox.  Results are however sometimes really bad and I need to find a better way to synthesize them and find the correct variables in the model. I should also look at the [[SEM]] again and model it again for myself to create a consistent result. 