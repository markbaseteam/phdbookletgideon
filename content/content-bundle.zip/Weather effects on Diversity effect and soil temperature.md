The idea is here to use whatever temporal variables that I have to use TS based Causal Inference methods to understand the relationship of the weather (Temp, Moisture, Seasonal cycle) and the soil temperature and the diversity effect on the soil temperature. 
This is equally than saying: Under wich conditions is the Diversity effect the strongest. 

We can use whatever we have, PCMCI, DEEP AR etc. etc. 
Also , this is closely related to [[]]